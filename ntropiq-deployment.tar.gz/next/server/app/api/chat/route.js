(()=>{var e={};e.id=276,e.ids=[276],e.modules={846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},2323:(e,t,n)=>{"use strict";n.d(t,{B5:()=>l,CR:()=>d,yR:()=>c});var r=n(7449);let o=()=>{let e=process.env.GEMINI_API_KEY;if(!e)throw console.error("GEMINI_API_KEY environment variable is not set"),Error("Gemini API key is not configured");return console.log("Initializing Gemini with API key:",e.substring(0,10)+"..."),new r.ij(e)},s=null,i=()=>{if(!s)try{s=o()}catch(e){return console.error("Failed to initialize Gemini:",e),null}return s},a=()=>{let e=i();if(!e)throw Error("Gemini AI is not properly initialized");return e.getGenerativeModel({model:"gemini-1.5-flash"})};async function l(e){try{let t;console.log("Generating chat response for message:",e.substring(0,50)+"...");let n=a(),r=/^(hi|hello|hey|good morning|good afternoon|good evening)!?$/i.test(e.trim()),o=e.trim().length<20&&!/\b(analyze|model|data|ML|machine learning|analytics|visualization|dashboard|SQL|python|statistics|correlation|regression|prediction)\b/i.test(e);t=r?`You are ntropiq AI, a friendly data analytics assistant. The user just greeted you with: "${e}"

Respond with a brief, warm greeting and let them know you can help with data analytics, machine learning, and insights. Keep it conversational and under 2 sentences.`:o?`You are ntropiq AI, a data analytics assistant. The user asked: "${e}"

Provide a brief, helpful response in 1-2 sentences. If it's not related to data analytics, gently redirect them to how you can help with data analysis, ML models, or insights.`:`You are ntropiq AI, an advanced analytics and machine learning assistant. You help users with data analysis, insights, and building ML models through natural language.

User message: ${e}

Provide a helpful, professional response. For technical questions, be detailed and actionable. Format your response in clean, readable text (not code blocks unless showing actual code). Use bullet points or numbered lists when helpful for clarity.`,console.log("Calling Gemini API...");let s=await n.generateContent(t),i=(await s.response).text();return console.log("Gemini response received, length:",i.length),i}catch(e){throw console.error("Error generating chat response:",e),console.error("Error details:",e.message,e.stack),e}}async function c(e){try{let t;console.log("Generating notebook insights for query:",e.substring(0,50)+"...");let n=a();t=e.trim().length<10||/^(help|what|how)$|^(data|analysis|model)$/i.test(e.trim())?`You are ntropiq AI in a notebook environment. The user entered: "${e}"

This query is too vague. Respond with:
1. A brief acknowledgment (1 sentence)
2. 2-3 specific clarifying questions to help them be more precise

Keep it concise and focused on getting the information needed to provide better analysis.`:`You are ntropiq AI in a notebook environment. The user wants: "${e}"

Provide a direct, concise response with:
1. A brief answer or insight (2-3 sentences max)
2. Key next steps or recommendations (bullet points)

Be concise and actionable. Do NOT ask clarifying questions unless the query is completely impossible to address without critical missing information. Focus on providing useful insights and next steps.`,console.log("Calling Gemini API for notebook insights...");let r=await n.generateContent(t),o=(await r.response).text();return console.log("Notebook insights response received, length:",o.length),o}catch(e){throw console.error("Error generating notebook insights:",e),console.error("Error details:",e.message,e.stack),e}}async function d(e,t="python"){try{let n=a(),r=`You are ntropiq AI in a notebook environment. Analyze this ${t} code:

\`\`\`${t}
${e}
\`\`\`

Provide a concise response with:
1. What the code does (1-2 sentences)
2. Key observations or issues (bullet points)
3. One specific improvement suggestion if applicable

Be brief and notebook-appropriate. No long explanations.`,o=await n.generateContent(r);return(await o.response).text()}catch(e){return console.error("Error analyzing code:",e),`**Code Analysis Error**

Unable to analyze the code. Please check for syntax errors and try again.

**Quick checks:**
• Proper indentation
• Closed parentheses and quotes
• Valid ${t} syntax`}}},2560:(e,t,n)=>{"use strict";n.r(t),n.d(t,{patchFetch:()=>g,routeModule:()=>d,serverHooks:()=>h,workAsyncStorage:()=>u,workUnitAsyncStorage:()=>p});var r={};n.r(r),n.d(r,{POST:()=>c});var o=n(6559),s=n(8088),i=n(7719),a=n(2190),l=n(2323);async function c(e){try{let{message:t}=await e.json();if(!t||"string"!=typeof t)return a.NextResponse.json({error:"Message is required and must be a string"},{status:400});let n=await (0,l.B5)(t);return a.NextResponse.json({response:n,timestamp:new Date().toISOString()})}catch(e){return console.error("Chat API error:",e),a.NextResponse.json({error:"Failed to generate response"},{status:500})}}let d=new o.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/chat/route",pathname:"/api/chat",filename:"route",bundlePath:"app/api/chat/route"},resolvedPagePath:"/Users/mayanktondak/Downloads/ntropiq-main/app/api/chat/route.ts",nextConfigOutput:"export",userland:r}),{workAsyncStorage:u,workUnitAsyncStorage:p,serverHooks:h}=d;function g(){return(0,i.patchFetch)({workAsyncStorage:u,workUnitAsyncStorage:p})}},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},6487:()=>{},8335:()=>{},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")}};var t=require("../../../webpack-runtime.js");t.C(e);var n=e=>t(t.s=e),r=t.X(0,[447,580,449],()=>n(2560));module.exports=r})();